export type SupportedLanguage = 'en' | 'ru' | 'es' | 'pt' | 'de' | 'fr' | 'zh';

export interface LanguageInfo {
  code: SupportedLanguage;
  name: string;
  nativeName: string;
  flag: string;
}

export const SUPPORTED_LANGUAGES: LanguageInfo[] = [
  { code: 'en', name: 'English', nativeName: 'English', flag: '🇺🇸' },
  { code: 'ru', name: 'Russian', nativeName: 'Русский', flag: '🇷🇺' },
  { code: 'es', name: 'Spanish', nativeName: 'Español', flag: '🇪🇸' },
  { code: 'pt', name: 'Portuguese', nativeName: 'Português', flag: '🇧🇷' },
  { code: 'de', name: 'German', nativeName: 'Deutsch', flag: '🇩🇪' },
  { code: 'fr', name: 'French', nativeName: 'Français', flag: '🇫🇷' },
  { code: 'zh', name: 'Chinese', nativeName: '简体中文', flag: '🇨🇳' },
];

export interface TranslationSchema {
  // Brand & General
  brand: {
    name: string;
    tagline: string;
    taglineShort: string;
    description: string;
  };

  // Terminology
  terminology: {
    project: string;
    pin: string;
    board: string;
    competitor: string;
    analytics: string;
    searchQuery: string;
    credits: string;
    account: string;
    settings: string;
    publishing: string;
    aiAssistant: string;
    research: string;
  };

  // Common UI words
  common: {
    save: string;
    saved: string;
    cancel: string;
    delete: string;
    edit: string;
    create: string;
    generate: string;
    generating: string;
    search: string;
    filter: string;
    export: string;
    copy: string;
    copied: string;
    close: string;
    refresh: string;
    status: string;
    actions: string;
    back: string;
    next: string;
    loading: string;
    viewAll: string;
    viewDetails: string;
    active: string;
    all: string;
    success: string;
    error: string;
    completed: string;
    pending: string;
    high: string;
    medium: string;
    low: string;
    na: string;
  };

  // Navigation
  nav: {
    dashboard: string;
    pinGenerator: string;
    reviewPins: string;
    keywordResearch: string;
    competitorAudit: string;
    calendar: string;
    boards: string;
    analytics: string;
    pricing: string;
    settings: string;
    creditsLeft: string;
    connected: string;
    switchTheme: string;
    userProfile: string;
    pinterestAccounts: string;
    connectAccount: string;
    unlimited: string;
    logout: string;
    login: string;
    changeAvatar: string;
  };

  // Dashboard
  dashboard: {
    title: string;
    subtitle: string;
    monthlyViews: string;
    pinImpressions: string;
    outboundClicks: string;
    saveRate: string;
    viewsGrowth: string;
    clicksGrowth: string;
    quickActions: string;
    generateBatch: string;
    runAudit: string;
    exploreKeywords: string;
    viewSchedule: string;
    scheduledQueue: string;
    recentPinPerformance: string;
    aiInsightTitle: string;
    aiInsightBody: string;
    takeAction: string;
    emptyQueue: string;
    reviewPendingNotice: string;
    startReviewBtn: string;
    autoScheduleTitle: string;
    configureTimeBtn: string;
    serverExecutionNote: string;
  };

  // Pin Generator
  generator: {
    title: string;
    subtitle: string;
    modeSingle: string;
    modeBatch: string;
    pinCountLabel: string;
    pinCountSubtitle: string;
    aspectRatioLabel: string;
    aspectRatioSubtitle: string;
    aspectSingle: string;
    aspectRandomizer: string;
    aspectMixPrompt: string;
    formatCurrentPin: string;
    formatGuideTitle: string;
    recommendedBoard: string;
    recommendedBoardBadge: string;
    topicLabel: string;
    topicPlaceholder: string;
    targetBoardLabel: string;
    pinToneLabel: string;
    tones: {
      inspirational: string;
      commercial: string;
      educational: string;
      aesthetic: string;
      viral: string;
    };
    generateBtn: string;
    generatingState: string;
    resultsTitle: string;
    titleOptions: string;
    descriptionLabel: string;
    altTextLabel: string;
    targetUrlLabel: string;
    targetUrlPlaceholder: string;
    ctaLabel: string;
    ctaPlaceholder: string;
    keywordsIncluded: string;
    canvasTitle: string;
    canvasSubtitle: string;
    headlineOverlay: string;
    subheadlineOverlay: string;
    brandingText: string;
    templateStyle: string;
    exportImageBtn: string;
    pushToCalendarBtn: string;
    savedToCalendar: string;
    batchGeneratedNotice: string;
  };

  // Keyword Explorer
  keywords: {
    title: string;
    subtitle: string;
    searchPlaceholder: string;
    categoryFilter: string;
    categories: {
      all: string;
      homeDecor: string;
      fashion: string;
      recipes: string;
      digitalProducts: string;
      wellness: string;
      travel: string;
      diyCrafts: string;
      business: string;
    };
    tableKeyword: string;
    tableVolume: string;
    tableTrend: string;
    tableCompetition: string;
    tableIntent: string;
    tableAction: string;
    generateFromKeyword: string;
    highIntentTags: string;
    relatedQueries: string;
    exportCsv: string;
  };

  // Competitor Analysis
  competitors: {
    title: string;
    subtitle: string;
    trackedCompetitors: string;
    addCompetitorBtn: string;
    inputPlaceholder: string;
    monthlyViews: string;
    followers: string;
    pinFrequency: string;
    topBoards: string;
    bestTimeToPin: string;
    visualScore: string;
    gapAnalysisTitle: string;
    gapAnalysisDesc: string;
    contentOpportunity: string;
    actionAudit: string;
    suggestedTitle: string;
    suggestedSubtitle: string;
    matchScore: string;
    addToAudit: string;
    addedToAudit: string;
    visitProfile: string;
    refreshSuggestions: string;
    saves: string;
    impressionsTotal: string;
    savesTotal: string;
    saveRateMetric: string;
    followersCount: string;
    dominantFormatLabel: string;
    pinsPerDayLabel: string;
    viralPinsHeading: string;
    rankedBySaves: string;
    generateSimilarPin: string;
    createPinOnTopic: string;
    competitorTop3Note: string;
    recommendedCount: string;
  };

  // Publishing Calendar
  calendar: {
    title: string;
    subtitle: string;
    monthTab: string;
    weekTab: string;
    queueTab: string;
    optimalHoursNotice: string;
    schedulePinBtn: string;
    emptyDay: string;
    statusScheduled: string;
    statusPublished: string;
    statusDraft: string;
    optimalSlotBadge: string;
    pinDetailsModal: string;
    timezoneLabel: string;
    serverTimeNote: string;
    chooseTimezone: string;
  };

  // Boards
  boards: {
    title: string;
    subtitle: string;
    createBoardBtn: string;
    totalBoards: string;
    totalPins: string;
    averageSeoScore: string;
    boardHealthAudit: string;
    optimizeBoardBtn: string;
    targetPinsWeekly: string;
    recommendedKeywords: string;
  };

  // Analytics
  analytics: {
    title: string;
    subtitle: string;
    timeframe7d: string;
    timeframe30d: string;
    timeframe90d: string;
    impressionsOverTime: string;
    outboundClickRate: string;
    saveBreakdown: string;
    topPerformingPins: string;
    seoHealthIndex: string;
    growthOpportunities: string;
  };

  // Settings
  settings: {
    title: string;
    subtitle: string;
    appearanceSection: string;
    appearanceSectionDesc: string;
    themeLightRose: string;
    themeLightRoseDesc: string;
    themeLightMono: string;
    themeLightMonoDesc: string;
    themeDarkRose: string;
    themeDarkRoseDesc: string;
    themeDarkMono: string;
    themeDarkMonoDesc: string;
    languageSection: string;
    languageSectionDesc: string;
    connectedAccountSection: string;
    connectedAccountDesc: string;
    billingSection: string;
    billingSectionDesc: string;
    currentPlan: string;
    upgradePlan: string;
    creditsUsed: string;
    resetCycle: string;
  };

  // Pricing & Credits
  pricing: {
    title: string;
    subtitle: string;
    currencyRub: string;
    currencyUsd: string;
    tabPlans: string;
    tabCredits: string;
    balanceTitle: string;
    subscriptionCreditsNotice: string;
    topupCreditsNotice: string;
    deductionRule: string;
    topupCreditsBtn: string;
    planAnalyticsTitle: string;
    planAnalyticsSubtitle: string;
    planAnalyticsDesc: string;
    planStartTitle: string;
    planStartSubtitle: string;
    planStartDesc: string;
    planProTitle: string;
    planProSubtitle: string;
    planProDesc: string;
    planAgencyTitle: string;
    planAgencySubtitle: string;
    planAgencyDesc: string;
    creditsPerMonth: string;
    accountsLabel: string;
    burnsNotice: string;
    includedFeatures: string;
    popularBadge: string;
    choosePlan: string;
    currentPlan: string;
    activePlan: string;
    rulesTitle: string;
    rule1Title: string;
    rule1Desc: string;
    rule2Title: string;
    rule2Desc: string;
    rule3Title: string;
    rule3Desc: string;
    creditsPackTitle: string;
    creditsPackDesc: string;
    neverBurnBadge: string;
    buyCreditsBtn: string;
    creditsBoughtSuccess: string;
    summaryTableTitle: string;
    thPack: string;
    thCredits: string;
    thPricePerCredit: string;
    thPriceRub: string;
    thPriceUsd: string;
    thCost: string;
    thNetProfit: string;
    thMargin: string;
    thAction: string;
    aiBotTitle: string;
    aiBotSubtitle: string;
    aiBotPlaceholder: string;
    aiBotAsk: string;
    aiBotOnline: string;
  };

  // Swipe Review & Approval Deck
  review: {
    title: string;
    subtitle: string;
    approveBtn: string;
    rejectBtn: string;
    keyboardTip: string;
    approvedCount: string;
    rejectedCount: string;
    reasonTitle: string;
    targetBoard: string;
    scheduledFor: string;
    allReviewed: string;
    allReviewedDesc: string;
    finishBtn: string;
  };

  // AI Strategist Bot Widget
  bot: {
    floatingButton: string;
    title: string;
    subtitle: string;
    statusOnline: string;
    disclaimerPeak: string;
    welcomeMessage: string;
    quickQuestion1: string;
    quickAnswer1: string;
    quickQuestion2: string;
    quickAnswer2: string;
    quickQuestion3: string;
    quickAnswer3: string;
    quickQuestion4: string;
    quickAnswer4: string;
    quickQuestion5: string;
    quickAnswer5: string;
    placeholder: string;
    send: string;
    thinking: string;
    clearChat: string;
    suggestedTitle: string;
  };

  // Notifications Bell & Queue System
  notifications: {
    bellTitle: string;
    title: string;
    markAllRead: string;
    empty: string;
    filterAll: string;
    filterQueue: string;
    statusQueued: string;
    statusInProgress: string;
    statusReady: string;
    viewResult: string;
  };

  // Terms & Peak Load Policy
  terms: {
    peakLoadTitle: string;
    peakLoadNotice: string;
    termsOfServiceTitle: string;
  };
}
